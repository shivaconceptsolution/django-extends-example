from django.apps import AppConfig


class UserappConfig(AppConfig):
    name = 'userapp'
