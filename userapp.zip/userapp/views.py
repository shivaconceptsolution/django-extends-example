from django.shortcuts import render

def index(request):
 return render(request,"userapp/index.html")
def about(request):
 return render(request,"userapp/about.html")
def services(request):
 return render(request,"userapp/services.html")
def contact(request):
 return render(request,"userapp/contact.html")
def gallery(request):
 return render(request,"userapp/gallery.html")
